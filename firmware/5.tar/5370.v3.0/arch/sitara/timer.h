#ifndef _TIMER_H
#define _TIMER_H

u4_t sys_now();

#endif
